var NAVTREE =
[
  [ "Embedded-System-Library (STM32F4xx)", "index.html", [
    [ "EmbSysLib", "index.html", null ],
    [ "Related Pages", "pages.html", [
      [ "Todo List", "todo.html", null ]
    ] ],
    [ "Class List", "annotated.html", [
      [ "cCRC", "classc_c_r_c.html", null ],
      [ "cDataPointer", "classc_data_pointer.html", null ],
      [ "cDevAnalog", "classc_dev_analog.html", null ],
      [ "cDevAnalogIn", "classc_dev_analog_in.html", null ],
      [ "cDevAnalogInADC", "classc_dev_analog_in_a_d_c.html", null ],
      [ "cDevAnalogOut", "classc_dev_analog_out.html", null ],
      [ "cDevAnalogOutDAC", "classc_dev_analog_out_d_a_c.html", null ],
      [ "cDevAnalogOutPWM", "classc_dev_analog_out_p_w_m.html", null ],
      [ "cDevAnalogOutPWMemul", "classc_dev_analog_out_p_w_memul.html", null ],
      [ "cDevDigital", "classc_dev_digital.html", null ],
      [ "cDevTextIO", "classc_dev_text_i_o.html", null ],
      [ "cDevTextIO_UART", "classc_dev_text_i_o___u_a_r_t.html", null ],
      [ "cFifo< T >", "classc_fifo.html", null ],
      [ "cHwADC", "classc_hw_a_d_c.html", null ],
      [ "cHwADC_0", "classc_hw_a_d_c__0.html", null ],
      [ "cHwDAC", "classc_hw_d_a_c.html", null ],
      [ "cHwDAC_0", "classc_hw_d_a_c__0.html", null ],
      [ "cHwEncoder", "classc_hw_encoder.html", null ],
      [ "cHwEncoder_Emul", "classc_hw_encoder___emul.html", null ],
      [ "cHwEncoder_N", "classc_hw_encoder___n.html", null ],
      [ "cHwI2Cmaster", "classc_hw_i2_cmaster.html", null ],
      [ "cHwI2Cmaster::Device", "classc_hw_i2_cmaster_1_1_device.html", null ],
      [ "cHwI2Cmaster_N", "classc_hw_i2_cmaster___n.html", null ],
      [ "cHwMemory", "classc_hw_memory.html", null ],
      [ "cHwMemory_Flash", "classc_hw_memory___flash.html", null ],
      [ "cHwMemory_RAM", "classc_hw_memory___r_a_m.html", null ],
      [ "cHwPinConfig", "classc_hw_pin_config.html", null ],
      [ "cHwPort", "classc_hw_port.html", null ],
      [ "cHwPort::Pin", "classc_hw_port_1_1_pin.html", null ],
      [ "cHwPort_N", "classc_hw_port___n.html", null ],
      [ "cHwRTC", "classc_hw_r_t_c.html", null ],
      [ "cHwRTC::Properties", "classc_hw_r_t_c_1_1_properties.html", null ],
      [ "cHwRTC_0", "classc_hw_r_t_c__0.html", null ],
      [ "cHwRTOS_MCU", "classc_hw_r_t_o_s___m_c_u.html", null ],
      [ "cHwSPImaster", "classc_hw_s_p_imaster.html", null ],
      [ "cHwSPImaster::Device", "classc_hw_s_p_imaster_1_1_device.html", null ],
      [ "cHwSPImaster_N", "classc_hw_s_p_imaster___n.html", null ],
      [ "cHwTimer", "classc_hw_timer.html", null ],
      [ "cHwTimer_N", "classc_hw_timer___n.html", null ],
      [ "cHwUART", "classc_hw_u_a_r_t.html", null ],
      [ "cHwUART_N", "classc_hw_u_a_r_t___n.html", null ],
      [ "cHwUSB", "classc_hw_u_s_b.html", null ],
      [ "cHwUSB_0", "classc_hw_u_s_b__0.html", null ],
      [ "cHwUSBctrl", "classc_hw_u_s_bctrl.html", null ],
      [ "cHwUSBdesc", "classc_hw_u_s_bdesc.html", null ],
      [ "cHwUSBdesc::cConfiguration", "classc_hw_u_s_bdesc_1_1c_configuration.html", null ],
      [ "cHwUSBdesc::cDevice", "classc_hw_u_s_bdesc_1_1c_device.html", null ],
      [ "cHwUSBdesc::cEndpoint", "classc_hw_u_s_bdesc_1_1c_endpoint.html", null ],
      [ "cHwUSBdesc::cHID", "classc_hw_u_s_bdesc_1_1c_h_i_d.html", null ],
      [ "cHwUSBdesc::cHID::_HID_DESCRIPTOR_LIST", "structc_hw_u_s_bdesc_1_1c_h_i_d_1_1___h_i_d___d_e_s_c_r_i_p_t_o_r___l_i_s_t.html", null ],
      [ "cHwUSBdesc::cInterface", "classc_hw_u_s_bdesc_1_1c_interface.html", null ],
      [ "cHwUSBdesc::cReport", "classc_hw_u_s_bdesc_1_1c_report.html", null ],
      [ "cHwUSBdesc::cString", "classc_hw_u_s_bdesc_1_1c_string.html", null ],
      [ "cHwUSBendpoint", "classc_hw_u_s_bendpoint.html", null ],
      [ "cHwUSBinterf", "classc_hw_u_s_binterf.html", null ],
      [ "cIPC", "classc_i_p_c.html", null ],
      [ "cIPC::Data< T, ID >", "classc_i_p_c_1_1_data.html", null ],
      [ "cIPC::DataInterface", "classc_i_p_c_1_1_data_interface.html", null ],
      [ "cIPC_UART", "classc_i_p_c___u_a_r_t.html", null ],
      [ "cIPC_USBdevice", "classc_i_p_c___u_s_bdevice.html", null ],
      [ "cIPC_USBdevice_DATA", "classc_i_p_c___u_s_bdevice___d_a_t_a.html", null ],
      [ "cList", "classc_list.html", null ],
      [ "cList::Item", "classc_list_1_1_item.html", null ],
      [ "cRTOS", "classc_r_t_o_s.html", null ],
      [ "cRTOS::Task", "classc_r_t_o_s_1_1_task.html", null ],
      [ "cRTOS::Timer", "classc_r_t_o_s_1_1_timer.html", null ],
      [ "cRTOS_RR< NUM_OF_TASK >", "classc_r_t_o_s___r_r.html", null ],
      [ "cSharedMem< T >", "classc_shared_mem.html", null ],
      [ "cSystem", "classc_system.html", null ],
      [ "cTaskHandler", "classc_task_handler.html", null ],
      [ "cTaskHandler::Task", "classc_task_handler_1_1_task.html", null ],
      [ "cTaskHandler::Timer", "classc_task_handler_1_1_timer.html", null ],
      [ "cTimer", "classc_timer.html", null ],
      [ "cUSBinterfClassVSC< IN_T, OUT_T >", "classc_u_s_binterf_class_v_s_c.html", null ]
    ] ],
    [ "Class Index", "classes.html", null ],
    [ "Class Hierarchy", "hierarchy.html", [
      [ "cCRC", "classc_c_r_c.html", null ],
      [ "cDataPointer", "classc_data_pointer.html", null ],
      [ "cDevAnalog", "classc_dev_analog.html", [
        [ "cDevAnalogIn", "classc_dev_analog_in.html", [
          [ "cDevAnalogInADC", "classc_dev_analog_in_a_d_c.html", null ]
        ] ],
        [ "cDevAnalogOut", "classc_dev_analog_out.html", [
          [ "cDevAnalogOutDAC", "classc_dev_analog_out_d_a_c.html", null ],
          [ "cDevAnalogOutPWM", "classc_dev_analog_out_p_w_m.html", null ],
          [ "cDevAnalogOutPWMemul", "classc_dev_analog_out_p_w_memul.html", null ]
        ] ]
      ] ],
      [ "cDevDigital", "classc_dev_digital.html", null ],
      [ "cDevTextIO", "classc_dev_text_i_o.html", [
        [ "cDevTextIO_UART", "classc_dev_text_i_o___u_a_r_t.html", null ]
      ] ],
      [ "cFifo< T >", "classc_fifo.html", null ],
      [ "cHwDAC", "classc_hw_d_a_c.html", [
        [ "cHwDAC_0", "classc_hw_d_a_c__0.html", null ]
      ] ],
      [ "cHwEncoder", "classc_hw_encoder.html", [
        [ "cHwEncoder_Emul", "classc_hw_encoder___emul.html", null ],
        [ "cHwEncoder_N", "classc_hw_encoder___n.html", null ]
      ] ],
      [ "cHwI2Cmaster", "classc_hw_i2_cmaster.html", [
        [ "cHwI2Cmaster_N", "classc_hw_i2_cmaster___n.html", null ]
      ] ],
      [ "cHwI2Cmaster::Device", "classc_hw_i2_cmaster_1_1_device.html", null ],
      [ "cHwMemory", "classc_hw_memory.html", [
        [ "cHwMemory_Flash", "classc_hw_memory___flash.html", null ],
        [ "cHwMemory_RAM", "classc_hw_memory___r_a_m.html", null ]
      ] ],
      [ "cHwPinConfig", "classc_hw_pin_config.html", null ],
      [ "cHwPort", "classc_hw_port.html", [
        [ "cHwPort_N", "classc_hw_port___n.html", null ]
      ] ],
      [ "cHwPort::Pin", "classc_hw_port_1_1_pin.html", null ],
      [ "cHwRTC", "classc_hw_r_t_c.html", [
        [ "cHwRTC_0", "classc_hw_r_t_c__0.html", null ]
      ] ],
      [ "cHwRTC::Properties", "classc_hw_r_t_c_1_1_properties.html", null ],
      [ "cHwRTOS_MCU", "classc_hw_r_t_o_s___m_c_u.html", null ],
      [ "cHwSPImaster", "classc_hw_s_p_imaster.html", [
        [ "cHwSPImaster_N", "classc_hw_s_p_imaster___n.html", null ]
      ] ],
      [ "cHwSPImaster::Device", "classc_hw_s_p_imaster_1_1_device.html", null ],
      [ "cHwTimer", "classc_hw_timer.html", [
        [ "cHwTimer_N", "classc_hw_timer___n.html", null ]
      ] ],
      [ "cHwUART", "classc_hw_u_a_r_t.html", [
        [ "cHwUART_N", "classc_hw_u_a_r_t___n.html", null ]
      ] ],
      [ "cHwUSB", "classc_hw_u_s_b.html", [
        [ "cHwUSB_0", "classc_hw_u_s_b__0.html", null ]
      ] ],
      [ "cHwUSBctrl", "classc_hw_u_s_bctrl.html", null ],
      [ "cHwUSBdesc", "classc_hw_u_s_bdesc.html", null ],
      [ "cHwUSBdesc::cConfiguration", "classc_hw_u_s_bdesc_1_1c_configuration.html", null ],
      [ "cHwUSBdesc::cDevice", "classc_hw_u_s_bdesc_1_1c_device.html", null ],
      [ "cHwUSBdesc::cEndpoint", "classc_hw_u_s_bdesc_1_1c_endpoint.html", null ],
      [ "cHwUSBdesc::cHID", "classc_hw_u_s_bdesc_1_1c_h_i_d.html", null ],
      [ "cHwUSBdesc::cHID::_HID_DESCRIPTOR_LIST", "structc_hw_u_s_bdesc_1_1c_h_i_d_1_1___h_i_d___d_e_s_c_r_i_p_t_o_r___l_i_s_t.html", null ],
      [ "cHwUSBdesc::cInterface", "classc_hw_u_s_bdesc_1_1c_interface.html", null ],
      [ "cHwUSBdesc::cReport", "classc_hw_u_s_bdesc_1_1c_report.html", null ],
      [ "cHwUSBdesc::cString", "classc_hw_u_s_bdesc_1_1c_string.html", null ],
      [ "cHwUSBendpoint", "classc_hw_u_s_bendpoint.html", null ],
      [ "cHwUSBinterf", "classc_hw_u_s_binterf.html", [
        [ "cUSBinterfClassVSC< IN_T, OUT_T >", "classc_u_s_binterf_class_v_s_c.html", null ],
        [ "cUSBinterfClassVSC< cIPC_USBdevice_DATA, cIPC_USBdevice_DATA >", "classc_u_s_binterf_class_v_s_c.html", [
          [ "cIPC_USBdevice", "classc_i_p_c___u_s_bdevice.html", null ]
        ] ]
      ] ],
      [ "cIPC", "classc_i_p_c.html", [
        [ "cIPC_UART", "classc_i_p_c___u_a_r_t.html", null ],
        [ "cIPC_USBdevice", "classc_i_p_c___u_s_bdevice.html", null ]
      ] ],
      [ "cIPC_USBdevice_DATA", "classc_i_p_c___u_s_bdevice___d_a_t_a.html", null ],
      [ "cList", "classc_list.html", null ],
      [ "cList::Item", "classc_list_1_1_item.html", [
        [ "cDevAnalogOutPWMemul", "classc_dev_analog_out_p_w_memul.html", null ],
        [ "cHwADC", "classc_hw_a_d_c.html", [
          [ "cHwADC_0", "classc_hw_a_d_c__0.html", null ]
        ] ],
        [ "cHwEncoder_Emul", "classc_hw_encoder___emul.html", null ],
        [ "cIPC::DataInterface", "classc_i_p_c_1_1_data_interface.html", [
          [ "cIPC::Data< T, ID >", "classc_i_p_c_1_1_data.html", null ]
        ] ],
        [ "cTaskHandler", "classc_task_handler.html", null ],
        [ "cTaskHandler::Task", "classc_task_handler_1_1_task.html", null ]
      ] ],
      [ "cRTOS", "classc_r_t_o_s.html", [
        [ "cRTOS_RR< NUM_OF_TASK >", "classc_r_t_o_s___r_r.html", null ]
      ] ],
      [ "cRTOS::Task", "classc_r_t_o_s_1_1_task.html", null ],
      [ "cSharedMem< T >", "classc_shared_mem.html", null ],
      [ "cSystem", "classc_system.html", null ],
      [ "cTimer", "classc_timer.html", [
        [ "cRTOS::Timer", "classc_r_t_o_s_1_1_timer.html", null ],
        [ "cTaskHandler::Timer", "classc_task_handler_1_1_timer.html", null ]
      ] ]
    ] ],
    [ "Class Members", "functions.html", null ],
    [ "File List", "files.html", [
      [ "Src/lib.cpp", "lib_8cpp.html", null ],
      [ "Src/lib.h", "lib_8h.html", null ],
      [ "Src/Device/Device.cpp", "_device_8cpp.html", null ],
      [ "Src/Device/Device.h", "_device_8h.html", null ],
      [ "Src/Device/Analog/devAnalog.cpp", "dev_analog_8cpp.html", null ],
      [ "Src/Device/Analog/devAnalog.h", "dev_analog_8h.html", null ],
      [ "Src/Device/Analog/devAnalogIn.cpp", "dev_analog_in_8cpp.html", null ],
      [ "Src/Device/Analog/devAnalogIn.h", "dev_analog_in_8h.html", null ],
      [ "Src/Device/Analog/devAnalogInADC.cpp", "dev_analog_in_a_d_c_8cpp.html", null ],
      [ "Src/Device/Analog/devAnalogInADC.h", "dev_analog_in_a_d_c_8h.html", null ],
      [ "Src/Device/Analog/devAnalogOut.cpp", "dev_analog_out_8cpp.html", null ],
      [ "Src/Device/Analog/devAnalogOut.h", "dev_analog_out_8h.html", null ],
      [ "Src/Device/Analog/devAnalogOutDAC.cpp", "dev_analog_out_d_a_c_8cpp.html", null ],
      [ "Src/Device/Analog/devAnalogOutDAC.h", "dev_analog_out_d_a_c_8h.html", null ],
      [ "Src/Device/Analog/devAnalogOutPWM.cpp", "dev_analog_out_p_w_m_8cpp.html", null ],
      [ "Src/Device/Analog/devAnalogOutPWM.h", "dev_analog_out_p_w_m_8h.html", null ],
      [ "Src/Device/Digital/devDigital.cpp", "dev_digital_8cpp.html", null ],
      [ "Src/Device/Digital/devDigital.h", "dev_digital_8h.html", null ],
      [ "Src/Device/TextIO/devTextIO.cpp", "dev_text_i_o_8cpp.html", null ],
      [ "Src/Device/TextIO/devTextIO.h", "dev_text_i_o_8h.html", null ],
      [ "Src/Device/TextIO/devTextIO_UART.cpp", "dev_text_i_o___u_a_r_t_8cpp.html", null ],
      [ "Src/Device/TextIO/devTextIO_UART.h", "dev_text_i_o___u_a_r_t_8h.html", null ],
      [ "Src/Hardware/Hardware.cpp", "_hardware_8cpp.html", null ],
      [ "Src/Hardware/Hardware.h", "_hardware_8h.html", null ],
      [ "Src/Hardware/Common/ADC.cpp", "_a_d_c_8cpp.html", null ],
      [ "Src/Hardware/Common/ADC.h", "_a_d_c_8h.html", null ],
      [ "Src/Hardware/Common/DAC.cpp", "_d_a_c_8cpp.html", null ],
      [ "Src/Hardware/Common/DAC.h", "_d_a_c_8h.html", null ],
      [ "Src/Hardware/Common/Encoder.cpp", "_encoder_8cpp.html", null ],
      [ "Src/Hardware/Common/Encoder.h", "_encoder_8h.html", null ],
      [ "Src/Hardware/Common/I2Cmaster.cpp", "_i2_cmaster_8cpp.html", null ],
      [ "Src/Hardware/Common/I2Cmaster.h", "_i2_cmaster_8h.html", null ],
      [ "Src/Hardware/Common/Memory.cpp", "_memory_8cpp.html", null ],
      [ "Src/Hardware/Common/Memory.h", "_memory_8h.html", null ],
      [ "Src/Hardware/Common/Port.cpp", "_port_8cpp.html", null ],
      [ "Src/Hardware/Common/Port.h", "_port_8h.html", null ],
      [ "Src/Hardware/Common/RTC.cpp", "_r_t_c_8cpp.html", null ],
      [ "Src/Hardware/Common/RTC.h", "_r_t_c_8h.html", null ],
      [ "Src/Hardware/Common/SPImaster.cpp", "_s_p_imaster_8cpp.html", null ],
      [ "Src/Hardware/Common/SPImaster.h", "_s_p_imaster_8h.html", null ],
      [ "Src/Hardware/Common/Timer.cpp", "_hardware_2_common_2_timer_8cpp.html", null ],
      [ "Src/Hardware/Common/Timer.h", "_hardware_2_common_2_timer_8h.html", null ],
      [ "Src/Hardware/Common/UART.cpp", "_u_a_r_t_8cpp.html", null ],
      [ "Src/Hardware/Common/UART.h", "_u_a_r_t_8h.html", null ],
      [ "Src/Hardware/Common/USB.cpp", "_hardware_2_common_2_u_s_b_8cpp.html", null ],
      [ "Src/Hardware/Common/USB.h", "_hardware_2_common_2_u_s_b_8h.html", null ],
      [ "Src/Hardware/Common/USB/USBctrl.cpp", "_u_s_bctrl_8cpp.html", null ],
      [ "Src/Hardware/Common/USB/USBctrl.h", "_u_s_bctrl_8h.html", null ],
      [ "Src/Hardware/Common/USB/USBdesc.cpp", "_u_s_bdesc_8cpp.html", null ],
      [ "Src/Hardware/Common/USB/USBdesc.h", "_u_s_bdesc_8h.html", null ],
      [ "Src/Hardware/Common/USB/USBendpoint.cpp", "_u_s_bendpoint_8cpp.html", null ],
      [ "Src/Hardware/Common/USB/USBendpoint.h", "_u_s_bendpoint_8h.html", null ],
      [ "Src/Hardware/Common/USB/USBhardware.cpp", "_u_s_bhardware_8cpp.html", null ],
      [ "Src/Hardware/Common/USB/USBhardware.h", "_u_s_bhardware_8h.html", null ],
      [ "Src/Hardware/Common/USB/USBinterf.cpp", "_u_s_binterf_8cpp.html", null ],
      [ "Src/Hardware/Common/USB/USBinterf.h", "_u_s_binterf_8h.html", null ],
      [ "Src/Hardware/MCU/System.h", "_system_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/MCU_STM32F4xx.cpp", "_m_c_u___s_t_m32_f4xx_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/MCU_STM32F4xx.h", "_m_c_u___s_t_m32_f4xx_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/ADC_MCU.cpp", "_a_d_c___m_c_u_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/ADC_MCU.h", "_a_d_c___m_c_u_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/DAC_MCU.cpp", "_d_a_c___m_c_u_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/DAC_MCU.h", "_d_a_c___m_c_u_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/Encoder_MCU.cpp", "_encoder___m_c_u_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/Encoder_MCU.h", "_encoder___m_c_u_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/I2Cmaster_MCU.cpp", "_i2_cmaster___m_c_u_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/I2Cmaster_MCU.h", "_i2_cmaster___m_c_u_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/Memory_Flash.cpp", "_memory___flash_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/Memory_Flash.h", "_memory___flash_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/Memory_RAM.cpp", "_memory___r_a_m_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/Memory_RAM.h", "_memory___r_a_m_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/Port_MCU.cpp", "_port___m_c_u_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/Port_MCU.h", "_port___m_c_u_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/RTC_MCU.cpp", "_r_t_c___m_c_u_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/RTC_MCU.h", "_r_t_c___m_c_u_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/SPImaster_MCU.cpp", "_s_p_imaster___m_c_u_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/SPImaster_MCU.h", "_s_p_imaster___m_c_u_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/Timer_MCU.cpp", "_timer___m_c_u_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/Timer_MCU.h", "_timer___m_c_u_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/UART_MCU.cpp", "_u_a_r_t___m_c_u_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/UART_MCU.h", "_u_a_r_t___m_c_u_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/USB_MCU.cpp", "_u_s_b___m_c_u_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Src/USB_MCU.h", "_u_s_b___m_c_u_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Sys/PinConfig.cpp", "_pin_config_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Sys/PinConfig.h", "_pin_config_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Sys/RTOS_MCU.cpp", "_r_t_o_s___m_c_u_8cpp.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Sys/RTOS_MCU.h", "_r_t_o_s___m_c_u_8h.html", null ],
      [ "Src/Hardware/MCU/STM32F4xx/Sys/System.cpp", "_system_8cpp.html", null ],
      [ "Src/Module/IPC.cpp", "_i_p_c_8cpp.html", null ],
      [ "Src/Module/IPC.h", "_i_p_c_8h.html", null ],
      [ "Src/Module/RTOS.cpp", "_r_t_o_s_8cpp.html", null ],
      [ "Src/Module/RTOS.h", "_r_t_o_s_8h.html", null ],
      [ "Src/Module/USB.cpp", "_module_2_u_s_b_8cpp.html", null ],
      [ "Src/Module/USB.h", "_module_2_u_s_b_8h.html", null ],
      [ "Src/Module/IPC/IPC.cpp", null, null ],
      [ "Src/Module/IPC/IPC.h", null, null ],
      [ "Src/Module/IPC/IPC_UART.cpp", null, null ],
      [ "Src/Module/IPC/IPC_UART.h", null, null ],
      [ "Src/Module/IPC/IPC_USBdevice.cpp", null, null ],
      [ "Src/Module/IPC/IPC_USBdevice.h", null, null ],
      [ "Src/Module/RTOS/RTOS.cpp", "_r_t_o_s_2_r_t_o_s_8cpp.html", null ],
      [ "Src/Module/RTOS/RTOS.h", "_r_t_o_s_2_r_t_o_s_8h.html", null ],
      [ "Src/Module/RTOS/RTOS_Scheduler.cpp", "_r_t_o_s___scheduler_8cpp.html", null ],
      [ "Src/Module/RTOS/RTOS_Scheduler.h", "_r_t_o_s___scheduler_8h.html", null ],
      [ "Src/Module/USB/USBinterfClassVSC.cpp", "_u_s_binterf_class_v_s_c_8cpp.html", null ],
      [ "Src/Module/USB/USBinterfClassVSC.h", "_u_s_binterf_class_v_s_c_8h.html", null ],
      [ "Src/Std/CRC.cpp", "_c_r_c_8cpp.html", null ],
      [ "Src/Std/CRC.h", "_c_r_c_8h.html", null ],
      [ "Src/Std/DataPointer.cpp", "_data_pointer_8cpp.html", null ],
      [ "Src/Std/DataPointer.h", "_data_pointer_8h.html", null ],
      [ "Src/Std/Fifo.cpp", "_fifo_8cpp.html", null ],
      [ "Src/Std/Fifo.h", "_fifo_8h.html", null ],
      [ "Src/Std/List.cpp", "_list_8cpp.html", null ],
      [ "Src/Std/List.h", "_list_8h.html", null ],
      [ "Src/Std/SharedMem.cpp", "_shared_mem_8cpp.html", null ],
      [ "Src/Std/SharedMem.h", "_shared_mem_8h.html", null ],
      [ "Src/Std/Std.cpp", "_std_8cpp.html", null ],
      [ "Src/Std/Std.h", "_std_8h.html", null ],
      [ "Src/Std/Timer.cpp", "_std_2_timer_8cpp.html", null ],
      [ "Src/Std/Timer.h", "_std_2_timer_8h.html", null ],
      [ "Src/Task/TaskHandler.cpp", "_task_handler_8cpp.html", null ],
      [ "Src/Task/TaskHandler.h", "_task_handler_8h.html", null ]
    ] ],
    [ "Examples", "examples.html", [
      [ "cCRC.cpp", "c_c_r_c_8cpp-example.html", null ],
      [ "cDevAnalog.cpp", "c_dev_analog_8cpp-example.html", null ],
      [ "cDevDigital.cpp", "c_dev_digital_8cpp-example.html", null ],
      [ "cDevTextIO.cpp", "c_dev_text_i_o_8cpp-example.html", null ],
      [ "cFifo.cpp", "c_fifo_8cpp-example.html", null ],
      [ "cHwADC.cpp", "c_hw_a_d_c_8cpp-example.html", null ],
      [ "cHwDAC.cpp", "c_hw_d_a_c_8cpp-example.html", null ],
      [ "cHwEncoder.cpp", "c_hw_encoder_8cpp-example.html", null ],
      [ "cHwI2Cmaster.cpp", "c_hw_i2_cmaster_8cpp-example.html", null ],
      [ "cHwMemory.cpp", "c_hw_memory_8cpp-example.html", null ],
      [ "cHwPort.cpp", "c_hw_port_8cpp-example.html", null ],
      [ "cHwRTC.cpp", "c_hw_r_t_c_8cpp-example.html", null ],
      [ "cHwRTOS.cpp", "c_hw_r_t_o_s_8cpp-example.html", null ],
      [ "cHwSPImaster.cpp", "c_hw_s_p_imaster_8cpp-example.html", null ],
      [ "cHwTimer.cpp", "c_hw_timer_8cpp-example.html", null ],
      [ "cHwUART.cpp", "c_hw_u_a_r_t_8cpp-example.html", null ],
      [ "cHwUSB.cpp", "c_hw_u_s_b_8cpp-example.html", null ],
      [ "cIPC.cpp", "c_i_p_c_8cpp-example.html", null ],
      [ "cList.cpp", "c_list_8cpp-example.html", null ],
      [ "cRTOS.cpp", "c_r_t_o_s_8cpp-example.html", null ],
      [ "cSharedMem.cpp", "c_shared_mem_8cpp-example.html", null ],
      [ "cTaskHandler.cpp", "c_task_handler_8cpp-example.html", null ],
      [ "cUSBinterfClassVSC.cpp", "c_u_s_binterf_class_v_s_c_8cpp-example.html", null ]
    ] ],
    [ "File Members", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

